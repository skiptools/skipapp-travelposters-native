package travel.posters.model

import skip.lib.*

import skip.foundation.*
class City: Identifiable<Int>, skip.bridge.kt.SwiftPeerBridged {
    var Swift_peer: skip.bridge.kt.SwiftObjectPointer

    constructor(Swift_peer: skip.bridge.kt.SwiftObjectPointer, marker: skip.bridge.kt.SwiftPeerMarker?) {
        this.Swift_peer = Swift_peer
    }

    fun finalize() {
        Swift_release(Swift_peer)
        Swift_peer = skip.bridge.kt.SwiftObjectNil
    }
    private external fun Swift_release(Swift_peer: skip.bridge.kt.SwiftObjectPointer)

    override fun Swift_bridgedPeer(): skip.bridge.kt.SwiftObjectPointer = Swift_peer

    override fun equals(other: Any?): Boolean {
        if (other !is skip.bridge.kt.SwiftPeerBridged) return false
        return Swift_peer == other.Swift_bridgedPeer()
    }

    override fun hashCode(): Int = Swift_peer.hashCode()

    override val id: Int
        get() = Swift_id(Swift_peer)
    private external fun Swift_id(Swift_peer: skip.bridge.kt.SwiftObjectPointer): Int
    val name: String
        get() = Swift_name(Swift_peer)
    private external fun Swift_name(Swift_peer: skip.bridge.kt.SwiftObjectPointer): String
    val tagline: String
        get() = Swift_tagline(Swift_peer)
    private external fun Swift_tagline(Swift_peer: skip.bridge.kt.SwiftObjectPointer): String
    val population: String
        get() = Swift_population(Swift_peer)
    private external fun Swift_population(Swift_peer: skip.bridge.kt.SwiftObjectPointer): String
    val country: String
        get() = Swift_country(Swift_peer)
    private external fun Swift_country(Swift_peer: skip.bridge.kt.SwiftObjectPointer): String
    val latitude: Double
        get() = Swift_latitude(Swift_peer)
    private external fun Swift_latitude(Swift_peer: skip.bridge.kt.SwiftObjectPointer): Double
    val longitude: Double
        get() = Swift_longitude(Swift_peer)
    private external fun Swift_longitude(Swift_peer: skip.bridge.kt.SwiftObjectPointer): Double
    val imageURL: java.net.URI
        get() = Swift_imageURL(Swift_peer)
    private external fun Swift_imageURL(Swift_peer: skip.bridge.kt.SwiftObjectPointer): java.net.URI
    val wikipediaURL: java.net.URI
        get() = Swift_wikipediaURL(Swift_peer)
    private external fun Swift_wikipediaURL(Swift_peer: skip.bridge.kt.SwiftObjectPointer): java.net.URI
    constructor(id: Int, name: String, tagline: String, population: String, country: String, latitude: Double, longitude: Double, imageURL: java.net.URI, wikipediaURL: java.net.URI) {
        Swift_peer = Swift_constructor_0(id, name, tagline, population, country, latitude, longitude, imageURL, wikipediaURL)
    }
    private external fun Swift_constructor_0(id: Int, name: String, tagline: String, population: String, country: String, latitude: Double, longitude: Double, imageURL: java.net.URI, wikipediaURL: java.net.URI): skip.bridge.kt.SwiftObjectPointer

    companion object {
    }
}
