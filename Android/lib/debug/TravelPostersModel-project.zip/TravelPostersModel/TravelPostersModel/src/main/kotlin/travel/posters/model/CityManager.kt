package travel.posters.model

import skip.lib.*
import skip.lib.Array

import skip.foundation.*
import skip.model.*
class CityManager: skip.bridge.kt.SwiftPeerBridged {
    var Swift_peer: skip.bridge.kt.SwiftObjectPointer

    constructor(Swift_peer: skip.bridge.kt.SwiftObjectPointer, marker: skip.bridge.kt.SwiftPeerMarker?) {
        this.Swift_peer = Swift_peer
    }

    fun finalize() {
        Swift_release(Swift_peer)
        Swift_peer = skip.bridge.kt.SwiftObjectNil
    }
    private external fun Swift_release(Swift_peer: skip.bridge.kt.SwiftObjectPointer)

    override fun Swift_bridgedPeer(): skip.bridge.kt.SwiftObjectPointer = Swift_peer

    override fun equals(other: Any?): Boolean {
        if (other !is skip.bridge.kt.SwiftPeerBridged) return false
        return Swift_peer == other.Swift_bridgedPeer()
    }

    override fun hashCode(): Int = Swift_peer.hashCode()
    var allCities: kotlin.collections.List<travel.posters.model.City>
        get() = Swift_allCities(Swift_peer)
        set(newValue) {
            @Suppress("NAME_SHADOWING") val newValue = newValue.sref()
            Swift_allCities_set(Swift_peer, newValue)
        }
    private external fun Swift_allCities(Swift_peer: skip.bridge.kt.SwiftObjectPointer): kotlin.collections.List<travel.posters.model.City>
    private external fun Swift_allCities_set(Swift_peer: skip.bridge.kt.SwiftObjectPointer, value: kotlin.collections.List<travel.posters.model.City>)
    var favoriteIDs: kotlin.collections.List<Int>
        get() = Swift_favoriteIDs(Swift_peer)
        set(newValue) {
            @Suppress("NAME_SHADOWING") val newValue = newValue.sref()
            Swift_favoriteIDs_set(Swift_peer, newValue)
        }
    private external fun Swift_favoriteIDs(Swift_peer: skip.bridge.kt.SwiftObjectPointer): kotlin.collections.List<Int>
    private external fun Swift_favoriteIDs_set(Swift_peer: skip.bridge.kt.SwiftObjectPointer, value: kotlin.collections.List<Int>)

    companion object {

        val shared: travel.posters.model.CityManager
            get() = Swift_Companion_shared()
        private external fun Swift_Companion_shared(): travel.posters.model.CityManager
    }
}
