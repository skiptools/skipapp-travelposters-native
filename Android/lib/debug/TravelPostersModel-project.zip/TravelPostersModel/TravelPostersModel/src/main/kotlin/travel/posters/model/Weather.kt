package travel.posters.model

import skip.lib.*

import skip.foundation.*
class Weather: skip.bridge.kt.SwiftPeerBridged {
    var Swift_peer: skip.bridge.kt.SwiftObjectPointer

    constructor(Swift_peer: skip.bridge.kt.SwiftObjectPointer, marker: skip.bridge.kt.SwiftPeerMarker?) {
        this.Swift_peer = Swift_peer
    }

    fun finalize() {
        Swift_release(Swift_peer)
        Swift_peer = skip.bridge.kt.SwiftObjectNil
    }
    private external fun Swift_release(Swift_peer: skip.bridge.kt.SwiftObjectPointer)

    override fun Swift_bridgedPeer(): skip.bridge.kt.SwiftObjectPointer = Swift_peer

    val latitude: Double
        get() = Swift_latitude(Swift_peer)
    private external fun Swift_latitude(Swift_peer: skip.bridge.kt.SwiftObjectPointer): Double
    val longitude: Double
        get() = Swift_longitude(Swift_peer)
    private external fun Swift_longitude(Swift_peer: skip.bridge.kt.SwiftObjectPointer): Double
    val time: Double
        get() = Swift_time(Swift_peer)
    private external fun Swift_time(Swift_peer: skip.bridge.kt.SwiftObjectPointer): Double
    val offset: Double
        get() = Swift_offset(Swift_peer)
    private external fun Swift_offset(Swift_peer: skip.bridge.kt.SwiftObjectPointer): Double
    val timezone: String
        get() = Swift_timezone(Swift_peer)
    private external fun Swift_timezone(Swift_peer: skip.bridge.kt.SwiftObjectPointer): String
    val tz: String
        get() = Swift_tz(Swift_peer)
    private external fun Swift_tz(Swift_peer: skip.bridge.kt.SwiftObjectPointer): String
    val elevation: Double
        get() = Swift_elevation(Swift_peer)
    private external fun Swift_elevation(Swift_peer: skip.bridge.kt.SwiftObjectPointer): Double
    val conditions: travel.posters.model.WeatherConditions
        get() = Swift_conditions(Swift_peer)
    private external fun Swift_conditions(Swift_peer: skip.bridge.kt.SwiftObjectPointer): travel.posters.model.WeatherConditions
    constructor(latitude: Double, longitude: Double, time: Double, offset: Double, timezone: String, tz: String, elevation: Double, conditions: travel.posters.model.WeatherConditions) {
        Swift_peer = Swift_constructor_1(latitude, longitude, time, offset, timezone, tz, elevation, conditions)
    }
    private external fun Swift_constructor_1(latitude: Double, longitude: Double, time: Double, offset: Double, timezone: String, tz: String, elevation: Double, conditions: travel.posters.model.WeatherConditions): skip.bridge.kt.SwiftObjectPointer
    override fun equals(other: Any?): Boolean {
        if (other === this) return true
        if (other !is Weather) return false
        return Swift_isequal(this, other)
    }
    private external fun Swift_isequal(lhs: Weather, rhs: Weather): Boolean
    override fun hashCode(): Int = Swift_hashvalue(Swift_peer).hashCode()
    private external fun Swift_hashvalue(Swift_peer: skip.bridge.kt.SwiftObjectPointer): Long

    companion object {
        suspend fun fetch(latitude: Double, longitude: Double): travel.posters.model.Weather = Async.run {
            kotlin.coroutines.suspendCoroutine { f_continuation ->
                Swift_callback_Companion_fetch_0(latitude, longitude) { f_return, f_error ->
                    if (f_error != null) {
                        f_continuation.resumeWith(kotlin.Result.failure(f_error))
                    } else {
                        f_continuation.resumeWith(kotlin.Result.success(f_return!!))
                    }
                }
            }
        }
        private external fun Swift_callback_Companion_fetch_0(latitude: Double, longitude: Double, f_callback: (travel.posters.model.Weather?, Throwable?) -> Unit)
    }
}
class WeatherConditions: skip.bridge.kt.SwiftPeerBridged {
    var Swift_peer: skip.bridge.kt.SwiftObjectPointer

    constructor(Swift_peer: skip.bridge.kt.SwiftObjectPointer, marker: skip.bridge.kt.SwiftPeerMarker?) {
        this.Swift_peer = Swift_peer
    }

    fun finalize() {
        Swift_release(Swift_peer)
        Swift_peer = skip.bridge.kt.SwiftObjectNil
    }
    private external fun Swift_release(Swift_peer: skip.bridge.kt.SwiftObjectPointer)

    override fun Swift_bridgedPeer(): skip.bridge.kt.SwiftObjectPointer = Swift_peer

    val temperature: Double
        get() = Swift_temperature(Swift_peer)
    private external fun Swift_temperature(Swift_peer: skip.bridge.kt.SwiftObjectPointer): Double
    val windspeed: Double
        get() = Swift_windspeed(Swift_peer)
    private external fun Swift_windspeed(Swift_peer: skip.bridge.kt.SwiftObjectPointer): Double
    val winddirection: Double
        get() = Swift_winddirection(Swift_peer)
    private external fun Swift_winddirection(Swift_peer: skip.bridge.kt.SwiftObjectPointer): Double
    val weathercode: Int
        get() = Swift_weathercode(Swift_peer)
    private external fun Swift_weathercode(Swift_peer: skip.bridge.kt.SwiftObjectPointer): Int
    val is_day: Int
        get() = Swift_is_day(Swift_peer)
    private external fun Swift_is_day(Swift_peer: skip.bridge.kt.SwiftObjectPointer): Int
    val time: String
        get() = Swift_time(Swift_peer)
    private external fun Swift_time(Swift_peer: skip.bridge.kt.SwiftObjectPointer): String
    constructor(temperature: Double, windspeed: Double, winddirection: Double, weathercode: Int, is_day: Int, time: String) {
        Swift_peer = Swift_constructor_0(temperature, windspeed, winddirection, weathercode, is_day, time)
    }
    private external fun Swift_constructor_0(temperature: Double, windspeed: Double, winddirection: Double, weathercode: Int, is_day: Int, time: String): skip.bridge.kt.SwiftObjectPointer
    override fun equals(other: Any?): Boolean {
        if (other === this) return true
        if (other !is WeatherConditions) return false
        return Swift_isequal(this, other)
    }
    private external fun Swift_isequal(lhs: WeatherConditions, rhs: WeatherConditions): Boolean
    override fun hashCode(): Int = Swift_hashvalue(Swift_peer).hashCode()
    private external fun Swift_hashvalue(Swift_peer: skip.bridge.kt.SwiftObjectPointer): Long

    companion object {
    }
}
