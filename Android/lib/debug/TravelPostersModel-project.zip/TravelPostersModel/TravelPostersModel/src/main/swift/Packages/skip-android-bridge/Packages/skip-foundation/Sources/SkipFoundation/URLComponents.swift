// Copyright 2023 Skip
//
// This is free software: you can redistribute and/or modify it
// under the terms of the GNU Lesser General Public License 3.0
// as published by the Free Software Foundation https://fsf.org

#if SKIP
import okhttp3.HttpUrl.Companion.toHttpUrl

public struct URLComponents : Hashable, Equatable, Sendable {
    public init() {
    }

    public init?(url: URL, resolvingAgainstBaseURL resolve: Bool) {
        self.url = url
    }

    public init?(string: String) {
        self.init(string: string, encodingInvalidCharacters: true)
    }

    public init?(string: String, encodingInvalidCharacters: Bool) {
        guard let url = URL(string: string, encodingInvalidCharacters: encodingInvalidCharacters) else {
            return nil
        }
        self.url = url
    }

    public var url: URL? {
        get {
            guard let string = self.string else {
                return nil
            }
            return URL(string: string)
        }
        set {
            self.scheme = newValue?.scheme
            self.host = newValue?.host(percentEncoded: false)
            self.port = newValue?.port
            self.path = newValue?.path(percentEncoded: false) ?? ""
            self.fragment = newValue?.fragment
            self.queryItems = URLQueryItem.from(newValue?.query(percentEncoded: false))
        }
    }

    public func url(relativeTo base: URL?) -> URL? {
        guard let string = self.string else {
            return nil
        }
        return URL(string: string, relativeTo: base)
    }

    public var string: String? {
        get {
            var string = ""
            if let scheme {
                string += scheme + ":"
            }
            if let host {
                if scheme != nil {
                    string += "//"
                }
                string += host
                if let port {
                    string += ":\(port)"
                }
            }
            string += path
            if let fragment {
                string += "#" + fragment
            }
            if let query = URLQueryItem.queryString(from: queryItems) {
                string += "?" + query
            }
            return string.isEmpty ? nil : string
        }
        set {
            if let newValue {
                self.url = URL(string: newValue)
            } else {
                self.url = nil
            }
        }
    }

    public var scheme: String? = nil
    public var host: String? = nil
    public var port: Int? = nil
    public var path = ""
    public var fragment: String? = nil
    public var queryItems: [URLQueryItem]? = nil

    @available(*, unavailable)
    public var user: String? {
        get {
            fatalError()
        }
        set {
        }
    }

    @available(*, unavailable)
    public var password: String? {
        get {
            fatalError()
        }
        set {
        }
    }

    public var query: String? {
        get {
            return URLQueryItem.queryString(from: queryItems)
        }
        set {
            queryItems = URLQueryItem.from(newValue)
        }
    }

    @available(*, unavailable)
    public var percentEncodedUser: String? {
        get {
            fatalError()
        }
        set {
        }
    }

    @available(*, unavailable)
    public var percentEncodedPassword: String? {
        get {
            fatalError()
        }
        set {
        }
    }

    public var percentEncodedHost: String? {
        get {
            return host?.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlHostAllowed)
        }
        set {
            host = newValue?.removingPercentEncoding
        }
    }

    public var encodedHost: String? {
        get {
            return percentEncodedHost
        }
        set {
            percentEncodedHost = newValue
        }
    }

    public var percentEncodedPath: String {
        get {
            return path.split(separator: "/", omittingEmptySubsequences: false)
                .map { $0.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlPathAllowed) ?? "" }
                .joined(separator: "/")
        }
        set {
            path = newValue.removingPercentEncoding ?? ""
        }
    }

    public var percentEncodedQuery: String? {
        get {
            return URLQueryItem.queryString(from: percentEncodedQueryItems)
        }
        set {
            self.query = newValue?.removingPercentEncoding
        }
    }

    public var percentEncodedFragment: String? {
        get {
            return fragment?.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlFragmentAllowed)
        }
        set {
            fragment = newValue?.removingPercentEncoding
        }
    }

    public var percentEncodedQueryItems: [URLQueryItem]? {
        get {
            return queryItems?.map { URLQueryItem(name: $0.name.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed) ?? "", value: $0.value?.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed)) }
        }
        set {
            queryItems = newValue?.map { URLQueryItem(name: $0.name.removingPercentEncoding ?? $0.name, value: $0.value?.removingPercentEncoding) }
        }
    }

    @available(*, unavailable)
    public var rangeOfScheme: Range<Int>? {
        fatalError()
    }

    @available(*, unavailable)
    public var rangeOfUser: Range<Int>? {
        fatalError()
    }

    @available(*, unavailable)
    public var rangeOfPassword: Range<Int>? {
        fatalError()
    }

    @available(*, unavailable)
    public var rangeOfHost: Range<Int>? {
        fatalError()
    }

    @available(*, unavailable)
    public var rangeOfPort: Range<Int>? {
        fatalError()
    }

    @available(*, unavailable)
    public var rangeOfPath: Range<Int>? {
        fatalError()
    }

    @available(*, unavailable)
    public var rangeOfQuery: Range<Int>? {
        fatalError()
    }

    @available(*, unavailable)
    public var rangeOfFragment: Range<Int>? {
        fatalError()
    }
}

public struct URLQueryItem : Hashable, Equatable, Sendable {
    public var name: String
    public var value: String?

    static func from(_ string: String?) -> [URLQueryItem]? {
        guard let string, !string.isEmpty else {
            return nil
        }
        do {
            // Use okhttp's query parsing
            guard let httpUrl = ("http://skip.tools/?" + string).toHttpUrl() else {
                return nil
            }
            return (0..<httpUrl.querySize).map { index in
                let name = httpUrl.queryParameterName(index)
                let value = httpUrl.queryParameterValue(index)
                return URLQueryItem(name: name, value: value)
            }
        } catch {
            return nil
        }
    }

    static func queryString(from items: [URLQueryItem]?) -> String? {
        guard let items, !items.isEmpty else {
            return nil
        }
        var query = ""
        for item in items {
            let name = item.name
            let value = item.value ?? ""
            if !query.isEmpty {
                query += "&"
            }
            query += name + "=" + value
        }
        return query
    }
}

#endif
