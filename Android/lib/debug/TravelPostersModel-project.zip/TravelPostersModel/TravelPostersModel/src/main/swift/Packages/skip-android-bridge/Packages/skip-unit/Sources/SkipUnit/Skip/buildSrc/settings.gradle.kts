pluginManagement {
    repositories {
        mavenCentral()
        gradlePluginPortal()
        google()
    }

}
