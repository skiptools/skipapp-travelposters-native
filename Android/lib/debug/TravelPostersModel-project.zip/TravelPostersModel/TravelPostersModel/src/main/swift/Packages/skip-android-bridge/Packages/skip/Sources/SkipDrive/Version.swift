// Copyright 2023 Skip

/// The current version of SkipDrive.
public let skipVersion = "1.2.1"
