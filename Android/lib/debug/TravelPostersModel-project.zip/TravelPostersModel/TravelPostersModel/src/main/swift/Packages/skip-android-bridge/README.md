# SkipAndroidBridge


```
ls -la ~/Library/Developer/Xcode/DerivedData/*/SourcePackages/plugins/skipapp-appdroid.output/AppDroid/skipstone/AppDroidModel/src/main/swift/Packages

skip-android-bridge -> ~/Library/Developer/Xcode/DerivedData/Skip-Everything-aqywrhrzhkbvfseiqgxuufbdwdft/SourcePackages/plugins/skip-android-bridge.output/SkipAndroidBridge/skipstone/SkipAndroidBridge/src/main/swift
skip-bridge -> /opt/src/github/skiptools/skip-bridge
skip-foundation -> /opt/src/github/skiptools/skip-foundation
skip-lib -> /opt/src/github/skiptools/skip-lib
skip-model -> /opt/src/github/skiptools/skip-model
skip-unit -> /opt/src/github/skiptools/skip-unit
swift-algorithms -> ~/Library/Developer/Xcode/DerivedData/Skip-Everything-aqywrhrzhkbvfseiqgxuufbdwdft/SourcePackages/checkouts/swift-algorithms
swift-android-native -> /opt/src/github/skiptools/swift-android-native
swift-numerics -> ~/Library/Developer/Xcode/DerivedData/Skip-Everything-aqywrhrzhkbvfseiqgxuufbdwdft/SourcePackages/checkouts/swift-numerics
```



