## 1.0.0

Released 2024-08-15


## 0.8.0

Released 2024-07-03

  - Update the using the Kotlin 2 integrated compose compiler
  - Bump androidx-compose-bom to 2024.06.00

## 0.7.0

Released 2024-05-25

  - Bump androidx-compose-bom to 2024.05.00
  - Update API support table colors

## 0.6.0

Released 2024-04-21

  - ci: update workflow actions location
  - Update README.md

## 0.5.5

Released 2024-04-21

  - ci: update workflow actions location
  - Update README.md

## 0.5.4

Released 2024-02-18

  - Move API list to end of README

## 0.5.2

Released 2024-02-10


## 0.5.1

Released 2024-02-08

  - Revert from androidx-compose-bom 2024.01.00 to 2023.10.01 to work around https://issuetracker.google.com/issues/322214617

## 0.5.0

Released 2024-02-05


## 0.4.1

Released 2024-01-29

  - Simpler, more robust state tracking
  - Update state tracking
  - Update README

## 0.4.0

Released 2024-01-10

  - Update SkipFoundation version dependency
  - Update Package.swift

## 0.3.3

Released 2023-12-11

  - Fix bug in Published property wrapper
  - Update skip dependency

## 0.3.2

Released 2023-12-09

  - Property wrapper model for observed properties
  - Notification center publisher support
  - Limited Publisher support

## 0.3.1

Released 2023-11-21

  - Update README
  - Update README

## 0.3.0

Released 2023-10-23

  - Update README

## 0.2.9

Released 2023-10-12


## 0.2.8

Released 2023-10-10


## 0.2.7

Released 2023-10-07


## 0.2.6

Released 2023-10-06

  - Export dependencies in build.gradle.kts as api

## 0.2.5

Released 2023-10-05


## 0.2.4

Released 2023-10-03


## 0.2.3

Released 2023-10-01


## 0.2.2

Released 2023-09-29

  - Remove SkipFoundation as dependency
  - Update README.md
  - Update README.md
  - Update README.md
  - README

## 0.2.1

Released 2023-09-18


## 0.2.0

Released 2023-09-13


## 0.1.1

Released 2023-09-13


## 0.1.0

Released 2023-09-13


## 0.0.6

Released 2023-09-11

  - Add Observation

## 0.0.5

Released 2023-09-09


## 0.0.4

Released 2023-09-09


## 0.0.3

Released 2023-09-08


## 0.0.2

Released 2023-09-08


